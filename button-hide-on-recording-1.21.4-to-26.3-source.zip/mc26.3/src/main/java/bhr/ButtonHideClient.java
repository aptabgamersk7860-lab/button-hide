package bhr;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class ButtonHideClient implements ClientModInitializer {
	private static final int TOGGLE_KEY = GLFW.GLFW_KEY_F9; // F9 toggles
	private static final String MATCH = "launcher";          // button label contains this
	private static boolean hidden = false;
	private static boolean wasDown = false;

	@Override
	public void onInitializeClient() {
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			long h = windowHandle(client);
			boolean down = h != 0L && GLFW.glfwGetKey(h, TOGGLE_KEY) == GLFW.GLFW_PRESS;
			if (down && !wasDown) {
				hidden = !hidden;
				try { client.gui.setOverlayMessage(Component.literal("Launcher button: " + (hidden ? "hidden" : "shown")), false); } catch (Throwable ignored) {}
			}
			wasDown = down;
			apply(client.screen);
		});
		ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> apply(screen));
	}

	/** Window handle; name differs between versions, so try both. */
	private static long windowHandle(Minecraft mc) {
		Object w = mc.getWindow();
		for (String n : new String[] { "handle", "getWindow" }) {
			try {
				Object r = w.getClass().getMethod(n).invoke(w);
				if (r instanceof Long l) return l;
			} catch (Throwable ignored) {}
		}
		return 0L;
	}

	private static void apply(Screen screen) {
		if (screen == null) return;
		for (var b : Screens.getButtons(screen)) {
			if (b.getMessage().getString().toLowerCase().contains(MATCH)) b.visible = !hidden;
		}
	}
}
