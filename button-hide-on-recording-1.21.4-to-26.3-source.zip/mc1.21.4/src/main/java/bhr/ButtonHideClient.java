package bhr;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ButtonHideClient implements ClientModInitializer {
	private static final int TOGGLE_KEY = GLFW.GLFW_KEY_F9; // F9 toggles
	private static final String MATCH = "launcher";          // button label contains this
	private static boolean hidden = false;
	private static boolean wasDown = false;

	@Override
	public void onInitializeClient() {
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			boolean down = InputUtil.isKeyPressed(client.getWindow().getHandle(), TOGGLE_KEY);
			if (down && !wasDown) {
				hidden = !hidden;
				try { client.inGameHud.setOverlayMessage(Text.literal("Launcher button: " + (hidden ? "hidden" : "shown")), false); } catch (Throwable ignored) {}
			}
			wasDown = down;
			apply(client.currentScreen);
		});
		ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> apply(screen));
	}

	private static void apply(Screen screen) {
		if (screen == null) return;
		for (var b : Screens.getButtons(screen)) {
			if (b.getMessage().getString().toLowerCase().contains(MATCH)) b.visible = !hidden;
		}
	}
}
